package com.example.pertemuan8_fix;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
