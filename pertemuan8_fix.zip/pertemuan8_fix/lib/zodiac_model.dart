class Zodiac {
  final String name;
  final String description;

  Zodiac({required this.name, required this.description});
}
