import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'zodiac_provider.dart';

class ResultScreen extends StatelessWidget {
  const ResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<ZodiacProvider>(context);
    final bulan = provider.birthDate?.month ?? 0;

    return Scaffold(
      appBar: AppBar(title: const Text("Hasil Ramalan")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text("Halo, ${provider.userName}!", style: const TextStyle(fontSize: 20)),
            const SizedBox(height: 10),
            Text("Zodiak kamu adalah: ${provider.zodiac?.name}",
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Text(provider.zodiac?.description ?? ""),
            const SizedBox(height: 20),
            Text("Bulan lahirmu adalah bulan ke-$bulan"),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Kembali"),
            ),
          ],
        ),
      ),
    );
  }
}
