import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'zodiac_provider.dart';
import 'result_screen.dart';

class InputScreen extends StatefulWidget {
  const InputScreen({super.key});

  @override
  State<InputScreen> createState() => _InputScreenState();
}

class _InputScreenState extends State<InputScreen> {
  final TextEditingController _nameController = TextEditingController();
  DateTime? selectedDate;

  void _pickDate() async {
    final DateTime? date = await showDatePicker(
      context: context,
      initialDate: DateTime(2005, 1, 1),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (date != null) {
      setState(() {
        selectedDate = date;
      });
    }
  }

  void _ramalZodiak() {
    if (_nameController.text.isNotEmpty && selectedDate != null) {
      Provider.of<ZodiacProvider>(context, listen: false)
          .setUserData(_nameController.text, selectedDate!);
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => const ResultScreen()),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Isi nama dan tanggal lahir terlebih dahulu')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Input Data')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text("NIM: 1234567890\nNama: Rahma Putri Dwi Swasti", textAlign: TextAlign.center),
            const SizedBox(height: 20),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Nama'),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              onPressed: _pickDate,
              child: Text(selectedDate == null
                  ? 'Pilih Tanggal Lahir'
                  : 'Tanggal: ${selectedDate!.day}/${selectedDate!.month}/${selectedDate!.year}'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _ramalZodiak,
              child: const Text('Ramal'),
            ),
          ],
        ),
      ),
    );
  }
}
