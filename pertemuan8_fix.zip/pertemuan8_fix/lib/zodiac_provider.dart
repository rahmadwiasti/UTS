import 'package:flutter/material.dart';
import 'zodiac_model.dart';

class ZodiacProvider with ChangeNotifier {
  String userName = '';
  DateTime? birthDate;
  Zodiac? zodiac;

  void setUserData(String name, DateTime date) {
    userName = name;
    birthDate = date;
    zodiac = getZodiac(date);
    notifyListeners();
  }

  Zodiac getZodiac(DateTime date) {
    final int day = date.day;
    final int month = date.month;

    if ((month == 12 && day >= 22) || (month == 1 && day <= 19)) {
      return Zodiac(name: 'Capricorn', description: '🐐 Kambing - Pekerja keras dan disiplin.');
    } else if ((month == 1 && day >= 20) || (month == 2 && day <= 18)) {
      return Zodiac(name: 'Aquarius', description: '🌊 Gelombang Air - Inovatif dan mandiri.');
    } else if ((month == 2 && day >= 19) || (month == 3 && day <= 20)) {
      return Zodiac(name: 'Pisces', description: '🐟 Ikan - Penuh empati dan imajinatif.');
    } else if ((month == 3 && day >= 21) || (month == 4 && day <= 20)) {
      return Zodiac(name: 'Aries', description: '🐏 Domba Jantan - Berani dan penuh semangat.');
    } else if ((month == 4 && day >= 21) || (month == 5 && day <= 20)) {
      return Zodiac(name: 'Taurus', description: '🐂 Lembu Jantan - Stabil dan dapat diandalkan.');
    } else if ((month == 5 && day >= 21) || (month == 6 && day <= 20)) {
      return Zodiac(name: 'Gemini', description: '👯 Saudara Kembar - Komunikatif dan cerdas.');
    } else if ((month == 6 && day >= 21) || (month == 7 && day <= 20)) {
      return Zodiac(name: 'Cancer', description: '🦀 Kepiting - Emosional dan penyayang.');
    } else if ((month == 7 && day >= 21) || (month == 8 && day <= 21)) {
      return Zodiac(name: 'Leo', description: '🦁 Singa - Percaya diri dan dominan.');
    } else if ((month == 8 && day >= 22) || (month == 9 && day <= 22)) {
      return Zodiac(name: 'Virgo', description: '👧 Gadis - Teliti dan perfeksionis.');
    } else if ((month == 9 && day >= 23) || (month == 10 && day <= 22)) {
      return Zodiac(name: 'Libra', description: '⚖️ Alat Penimbang - Adil dan seimbang.');
    } else if ((month == 10 && day >= 23) || (month == 11 && day <= 22)) {
      return Zodiac(name: 'Scorpio', description: '🦂 Kalajengking - Intens dan misterius.');
    } else if ((month == 11 && day >= 23) || (month == 12 && day <= 21)) {
      return Zodiac(name: 'Sagitarius', description: '🏹 Pemanah - Petualang dan optimis.');
    } else {
      return Zodiac(name: 'Unknown', description: 'Zodiak tidak dikenali.');
    }
  }
}
