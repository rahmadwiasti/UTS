import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'zodiac_provider.dart';
import 'input_screen.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (_) => ZodiacProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ramalan Zodiak',
      theme: ThemeData(primarySwatch: Colors.pink),
      home: const InputScreen(),
    );
  }
}
